SIMOS18 Torque Pro Package V2 (OEM GTI Red / Vertical)
Import order:
1) SIMOS18_PIDs.csv
2) SIMOS18_Dashboard_Vertical_GTI_Red.pro
Then enable alarms.
